-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2024 at 11:42 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ctc`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `DepartmentID` varchar(2) NOT NULL,
  `DepartmentName` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`DepartmentID`, `DepartmentName`) VALUES
('AC', 'บัญชี'),
('IT', 'เทคโนโลยีสารสนเทศ'),
('TD', 'เทคโนโลยีดิจิทัล');

-- --------------------------------------------------------

--
-- Table structure for table `tb_d5`
--

CREATE TABLE `tb_d5` (
  `std_id` bigint(11) NOT NULL,
  `f_name` varchar(40) NOT NULL,
  `l_name` varchar(40) NOT NULL,
  `DepartmentID` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_d5`
--

INSERT INTO `tb_d5` (`std_id`, `f_name`, `l_name`, `DepartmentID`) VALUES
(67319010041, 'มาลินี', 'ฉ่ำชูศรี', 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `tb_d5_67`
--

CREATE TABLE `tb_d5_67` (
  `std_id` bigint(11) NOT NULL,
  `DepartmentID` varchar(2) NOT NULL,
  `n_title` varchar(10) NOT NULL,
  `f_name` varchar(40) NOT NULL,
  `l_name` varchar(40) NOT NULL,
  `n_name` varchar(10) NOT NULL,
  `sex` varchar(5) NOT NULL,
  `number` varchar(10) NOT NULL,
  `e_mail` varchar(40) NOT NULL,
  `profile_link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_d5_67`
--

INSERT INTO `tb_d5_67` (`std_id`, `DepartmentID`, `n_title`, `f_name`, `l_name`, `n_name`, `sex`, `number`, `e_mail`, `profile_link`) VALUES
(6731901055, 'IT', 'นางสาว', 'คำปอง', 'เบียดนอก', 'กัร', 'หญิง', '', '', ''),
(67319010024, 'IT', 'นาย', 'วัชรพงศ์', 'แขมคำ', 'นิว', 'ชาย', '0635123347', 'd5_67319010024@ccollege.ac.th', ''),
(67319010025, 'IT', 'นาย', 'รัฐศาสตร์', 'สิงห์วงศ์', 'แฟรงค์', 'ชาย', '0652367535', 'd5_67319010025@ccollege.ac.th', 'fff\\fff\\frank--.php'),
(67319010026, 'IT', 'นาย', 'หัสดี', 'ศุภผล', 'มิกซ์', 'ชาย', '0979857837', 'd5_67319010026@ccollege.ac.th', ''),
(67319010030, 'IT', 'นางสาว', 'จิราภา', 'ทองรุ่ง', 'มายด์', 'หญิง', '0972679792', 'd5_67319010030@ccollege.ac.th', 'mind\\mind\\index.php'),
(67319010033, 'IT', 'นาย', 'นพนัฐ', 'มาลา', 'นัฐ', 'ชาย', '0638397659', 'd5_67319010033@ccollege.ac.th', 'nut\\nut\\nut.php'),
(67319010034, 'IT', 'นาย', 'ธนยศ', 'พันธุ์เกิด', 'มะขาม', 'ชาย', '0646434453', 'd5_67319010034@ccollege.ac.th', 'มะขาม\\มะขาม\\ประวัติส่วนตัว.php'),
(67319010035, 'IT', 'นาย', 'รัฐภูมิ', 'เบียดนอก', 'อังเดย์', 'ชาย', '0635123347', 'd5_67319010035@ccollege.ac.th', ''),
(67319010036, 'IT', 'นาย', 'ธีรภัทร', 'คำหงษา', 'อิ่ม', 'ชาย', '0612844292', 'd5_67319010036@ccollege.ac.th', 'อิ่ม ธีรภัทร\\อิ่ม ธีรภัทร\\Untitled-1.php'),
(67319010037, 'IT', 'นาย', 'รัฐภูมิ', 'คนเพียร', 'ฟิล์ม', 'ชาย', '0653150450', 'd5_67319010037@ccollege.ac.th', 'fim2 (1)\\flim\\flim.php'),
(67319010041, 'IT', 'นางสาว', 'มาลินี', 'ฉ่ำชูศรี', 'เปีย', 'หญิง', '0990892251', 'd5_67319010041@ccollege.ac.th', 'inpia.php');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `urole` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `password`, `urole`, `created_at`) VALUES
(3, 'มาลินี', 'ฉ่ำชูศรี', 'loeghso@gmail.com', '$2y$10$cA76Z6cCUqdfSUadJ2AAyOouMe10V3jUxn4RmMCTRjcK0paDW2d6q', 'user', '2024-07-08 08:35:21'),
(4, 'คงควรคอย', 'หัวใจ', 'd5_6731910041@ccollege.ac.th', '$2y$10$Q8jmkoX4rC7m/YFManSHB.SoCfFViDtq6vGJhj/kUKJMXh5L2HZbm', 'admin', '2024-07-08 08:45:12'),
(5, 'มาลินี', 'หัวใจ', 'aaa@gmail.com', '$2y$10$H3ATqVFj0qHcsd1wHgAS2.SlaYNYzJG6mbq/kFLP6SFwNqn61Mgtu', 'admin', '2024-08-24 03:34:33'),
(6, 'มาลินี', 'หัวใจ', 'bbb@gmail.com', '$2y$10$.AjAh0DRuqavBc.9bO2rYOfAxunyXb.RxpbLvkCSn8RxG1uA2x8hu', 'user', '2024-08-24 03:43:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`DepartmentID`);

--
-- Indexes for table `tb_d5`
--
ALTER TABLE `tb_d5`
  ADD PRIMARY KEY (`std_id`),
  ADD KEY `ctc` (`DepartmentID`);

--
-- Indexes for table `tb_d5_67`
--
ALTER TABLE `tb_d5_67`
  ADD PRIMARY KEY (`std_id`),
  ADD KEY `DepartmentID` (`DepartmentID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_d5`
--
ALTER TABLE `tb_d5`
  ADD CONSTRAINT `ctc` FOREIGN KEY (`DepartmentID`) REFERENCES `department` (`DepartmentID`);

--
-- Constraints for table `tb_d5_67`
--
ALTER TABLE `tb_d5_67`
  ADD CONSTRAINT `tb_d5_67_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `department` (`DepartmentID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
