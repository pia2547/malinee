<?php /* * No Copyright for Education (Free to Use and Edit) * * /
PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018 */ ?>
<html>

<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<link rel="stylesheet" href="ho.css.">
</head>

<body>
    <h2>เพิ่มข้อมูล</h2>
    <form action="insertdata.php" method="post" name="tb_d5_67">
    <div class="container mt-3">

<table class="table table-bordered">
<thead class="table-danger">
            <tr>
                <td>รหัสนักศึกษา : </td>
                <td><input type="text" name="std_id"></td>
            </tr>
            <tr>
                <td>แผนกวิชา: </td>
                <td><input type="text" name="DepartmentID"></td>
            </tr>
            <tr>
                <td>คำนำหน้า : </td>
                <td><input type="text" name="n_title"></td>
            </tr>
            <tr>
                <td>ชื่อ : </td>
                <td><input type="text" name="f_name"></td>
            </tr>
            <tr>
                <td>สกุล : </td>
                <td><input type="text" name="l_name"></td>
            </tr>
            <tr>
                <td>ชื่อเล่น: </td>
                <td><input type="text" name="n_name"></td>
            </tr>
            <tr>
                <td>เพศ : </td>
                <td><input type="text" name="sex"></td>
            </tr>
            <tr>
                <td>เบอร์ : </td>
                <td><input type="text" name="number"></td>
            </tr>
            <tr>
                <td>อีเมล : </td>
                <td><input type="text" name="e_mail"></td>
            </tr>
            
        </table>
        </thead>
        <br>
        <input type="submit" value="Insert Data">
    </form>
</body>

</html>