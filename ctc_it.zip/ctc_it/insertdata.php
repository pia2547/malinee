<?php
require('connect.php');

// Validate and sanitize input
$std_id         = mysqli_real_escape_string($conn, $_REQUEST['std_id']);
$n_title        = mysqli_real_escape_string($conn, $_REQUEST['n_title']);
$f_name         = mysqli_real_escape_string($conn, $_REQUEST['f_name']);
$l_name         = mysqli_real_escape_string($conn, $_REQUEST['l_name']);
$n_name         = mysqli_real_escape_string($conn, $_REQUEST['n_name']);
$sex            = mysqli_real_escape_string($conn, $_REQUEST['sex']);
$DepartmentID   = mysqli_real_escape_string($conn, $_REQUEST['DepartmentID']);

// Prepare SQL statement to prevent SQL injection
$sql = "INSERT INTO tb_d5_67 (std_id, n_title, f_name, l_name, n_name, sex, DepartmentID) 
        VALUES (?, ?, ?, ?, ?, ?, ?)";

if ($stmt = mysqli_prepare($conn, $sql)) {
    // Bind parameters
    mysqli_stmt_bind_param($stmt, "sssssss", $std_id, $n_title, $f_name, $l_name, $n_name, $sex, $DepartmentID);
    
    // Execute the prepared statement
    if (mysqli_stmt_execute($stmt)) {
        echo "ข้อมูลถูกเพิ่มเรียบร้อยแล้ว";
    } else {
        echo "Error: Unable to execute query. " . mysqli_stmt_error($stmt);
    }

    // Close statement
    mysqli_stmt_close($stmt);
} else {
    echo "Error: Unable to prepare the SQL statement. " . mysqli_error($conn);
}

// Close database connection
mysqli_close($conn);
?>