

<h1 style="color:rgb(230, 158, 152);"></h1>
<head><style>
    #s1 {
      border: 2px solid rgb(89, 202, 236);
      padding: 25px;
      background-color: rgb(89, 202, 236);
      background-repeat: no-repeat;
      background-size: auto;
    }

  </style>
  </head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


<body style="color:rgb(13, 98, 224);: url(.jpg);">
    <div class="container-fluid p-5 bg-info text-white text-center">
        <h1>แผนกเทคโนโลยีสารสนเทศ วิทยาลัยเทคนิคชัยภูมิ </h1>
        <p>ปวส.1 ห้อง D5</p> 
      </div>
        
      <div class="container mt-5">
        <div class="row">
          <div class="col-sm-4">
            <h3>เปีย 1</h3>
            <p> <div id="s1" class="card" style="width:250px">
                <img class="card-img-top" src="k.jpg" alt="Card image" style="width: 100%">
                <div class="card-body">
                  <h4 class="card-title">นางสาวมาลินี ฉ่ำชูศรี</h4>
                  <p class="card-text">รหัสนักศึกษา 67319010041</p>
                  <a href="C:\xampp\htdocs\taetd5\index.html" class="btn btn-primary">See Profile</a>
                </div>
              </div></p>
            <p></p>
          </div>
          <div class="col-sm-4">
            <h3>มายด์ 2</h3>
            <p> <div id="s1" class="card" style="width:250px">
                <img class="card-img-top" src="0.jpg" alt="Card image" style="width:100%">
                <div class="card-body">
                  <h4 class="card-title">นางสางจิราภา ทองรุ้ง</h4>
                  <p class="card-text">รหัสนักศึกษา 67319010030</p>
                  <a href="C:\xampp\htdocs\taetd5\mind\mind\index.html" class="btn btn-primary">See Profile</a>
                </div>
              </div></p>
            <p></p>
          </div>
          <div class="col-sm-4">
            <h3>นัฐ 3</h3>        
            <p> <div id="s1" class="card" style="width:250px">
                <img class="card-img-top" src="1.jpg" alt="Card image" style="width:100%">
                <div class="card-body">
                  <h4 class="card-title">นายนพนัฐ มาลา</h4>
                  <p class="card-text">รหัสนักศึกษา 67319010033</p>
                  <a href="C:\xampp\htdocs\taetd5\nut\nut\nut.html" class="btn btn-primary">See Profile</a>
                </div>
              </div></p>
            <p></p>
          </div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-sm-4">
            <h3>แฟรงค์ 4</h3>
            <p> <div id="s1" class="card" style="width:250px">
                <img class="card-img-top" src="2.jpg" alt="Card image" style="width:100%">
                <div class="card-body">
                  <h4 class="card-title">นายรัฐศาสตร์ สิงห์วงศ์</h4>
                  <p class="card-text">รหัสนักศึกษา 67319010025</p>
                  <a href="C:\xampp\htdocs\taetd5\fff\fff\frank--.html" class="btn btn-primary">See Profile</a>
                </div>
              </div></p>
            <p></p>
          </div>
          <div class="col-sm-4">
            <h3>อังเดย์ 5</h3>
            <p> <div id="s1" class="card" style="width:250px">
                <img class="card-img-top" src="3.jpg" alt="Card image" style="width:100%">
                <div class="card-body">
                  <h4 class="card-title">นายรัฐภูมิ เบียดนอก</h4>
                  <p class="card-text">รหัสนักศึกษา 67319010035</p>
                  <a href="#" class="btn btn-primary">See Profile</a>
                </div>
              </div></p>
            <p></p>
          </div>
          <div class="col-sm-4">
            <h3>ฟิล์ม 6</h3>        
            <p> <div id="s1" class="card" style="width:250px">
                <img class="card-img-top" src="9.jpg" alt="Card image" style="width:100%">
                <div class="card-body">
                  <h4 class="card-title">นายรัฐภูมิ คนเพียร</h4>
                  <p class="card-text">รหัสนักศึกษา 67319010037</p>
                  <a href="C:\xampp\htdocs\taetd5\fim2 (1)\flim\index.html" class="btn btn-primary">See Profile</a>
                </div>
              </div></p>
            <p></p>
          </div>
        </div>
        <div class="container mt-5">
            <div class="row">
              <div class="col-sm-4">
                <h3>มิกซ์ 7</h3>
                <p> <div id="s1" class="card" style="width:250px">
                    <img class="card-img-top" src="5.jpg" alt="Card image" style="width:100%">
                    <div class="card-body">
                      <h4 class="card-title">นายหัสดี ศุภผล</h4>
                      <p class="card-text">รหัสนักศึกษา 67319010026</p>
                      <a href="" class="btn btn-primary">See Profile</a>
                    </div>
                  </div></p>
                <p></p>
              </div>
              <div class="col-sm-4">
                <h3>อิ่ม 8</h3>
                <p> <div id="s1" class="card" style="width:250px">
                    <img class="card-img-top" src="6.jpg" alt="Card image" style="width:100%">
                    <div class="card-body">
                      <h4 class="card-title">นายธีรภัทร คำหงษา</h4>
                      <p class="card-text">รหัสนักศึกษา 67319010036</p>
                      <a href="C:\xampp\htdocs\taetd5\อิ่ม ธีรภัทร\อิ่ม ธีรภัทร\Untitled-1.html" class="btn btn-primary">See Profile</a>
                    </div>
                  </div></p>
                <p></p>
              </div>
              <div class="col-sm-4">
                <h3>มะขาม 9</h3>        
                <p> <div id="s1" class="card" style="width:250px">
                    <img class="card-img-top" src="7.jpg" alt="Card image" style="width:100%">
                    <div class="card-body">
                      <h4 class="card-title">นายธนยศ พันธุ์เกิด</h4>
                      <p class="card-text">รหัสนักศึกษา 67319010034</p>
                      <a href="C:\xampp\htdocs\taetd5\มะขาม\มะขาม\ประวัติส่วนตัว.html" class="btn btn-primary">See Profile</a>
                    </div>
                  </div></p>
                <p></p>
              </div>
            </div>
            <div class="col-sm-4">
                <h3>นิว 10</h3>        
                <p> <div id="s1" class="card" style="width:250px">
                    <img class="card-img-top" src="8.jpg" alt="Card image" style="width:100%">
                    <div class="card-body">
                      <h4 class="card-title">นายวัชรพงศ์ แขมคำ</h4>
                      <p class="card-text">รหัสนักศึกษา 67319010024</p>
                      <a href="#" class="btn btn-primary">See Profile</a>
                    </div>
                    
                 
</body>
 
  