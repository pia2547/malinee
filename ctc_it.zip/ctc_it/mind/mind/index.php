<!DOCTYPE html>
<html>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
  </script>

<head>
  <title>ประวัติส่วนตัว</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</head>

<h1 style="color:rgb(10, 10, 10);">ประวัติส่วนตัว</h1>

<body style="background-image: url(cc.jpg);"></body>



  

<img src="tt.jpg" alt="Trulli" width="259" height="250">
<h1 style="color:rgb(0, 0, 0);">ประวัติส่วนตัวของฉัน</h1>
<h2 style="color:rgb(209, 36, 171);">ชื่อ-สกุล: นางสาวจิราภา ทองรุ่ง</h2>
<h2 style="color:rgb(209, 36, 171);">แผนก: เทคโนโลยีสารสนเทศ(it)</h2>
<h2 style="color:rgb(209, 36, 171);">อายุ:18 ปี เกิดวันที่13/13/2548</h2>
<h2 style="color:rgb(209, 36, 171);">ชื่อเล่น: มายด์ กรุ๊บเลือด:บี</h2>
<h2 style="color:rgb(209, 36, 171);">เกี่ยวกับฉัน: ส่วนสูง :150 mm นํ้าหนัก:59 kg ชอบอนิเมะ เเละเล่นเกมส์</h2>
<h1 style="color:rgb(14, 13, 13);">ที่อยู่ปัจจุบัน</h1>
<h2 style="color:rgb(237, 64, 253);">186/2 บ.ดอนหัน ต.โนนสะอาด อ.คอนสวรรค์ จ.ชัยภูมิ</h2>
<h1 style="color:rgb(14, 12, 12);">ช่องทางการติดต่อ</h1>
<h2 style="color:rgb(209, 36, 171);">gmail:thongrungj@gmail.com</h2>
<h2 style="color:rgb(209, 36, 171);">facebook:jirapha thongrung</h2>
<h2 style="color:rgb(209, 36, 171);">เบอร์โทรศัพท์:0972679792</h2>
<h1 style="color:rgb(6, 3, 8);">ข้อมูลส่วนตัว</h1>
<h2 style="color:rgb(73, 36, 209);">ชื่อบิดา: นายชุมพร ทองรุ่ง อายุ:53ปี </h2>
<h2 style="color:rgb(62, 32, 129);">อาชีพ: เกษตรกร </h2>
<h2 style="color:rgb(14, 16, 179);">ชื่อมารดา: นางธัญพร ทองรุ่ง อายุ:50ปี</h2>
<h2 style="color:rgb(50, 18, 190);">อาชีพ: เกษตรกร เบอร์โทรศัพท์:0932261774</h2>
<h1 style="color:rgb(17, 15, 15);">ประวัติศึกษา</h1>
<h2 style="color:rgb(32, 49, 196);">จบจากโรงเรียนโนนสะอาดวิทยา เกรดเฉลี่ย:3.42</h2>
<h1 style="color:rgb(12, 11, 11);">คติประจำใจ</h1>
<h2 style="color:rgb(19, 15, 230);"> อย่าคิดว่าทำไม่ได้ ถ้ายังไม่ลงมือทำ</h2>
<h1 style="color:rgb(12, 10, 10);">งานอดิเรก</h1>
<h2 style="color:rgb(23, 0, 155);">เล่นเกมส์ ฟังเพลง วาดรูป ร้องเพลง</h2>
<h1 style="color:rgb(8, 8, 8);">นักศึกษาเลือกเรียนสาขานี้เพราะอะไร เรียนจบอยากทำอาชีพอะไร</h1>
<h2 style="color:rgb(36, 53, 209);">ชอบการออกเเบบเเละชอบเล่นเกมส์ อยากจะเป็นนักออกแบบเว็บหรืออะไรต่างๆ เเละ
  อยากจะเป็ยนักโปรเเกรมเมอร์</h2>




</body>

</html>