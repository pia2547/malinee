<!DOCTYPE html>
<html>
<head>
<title>สวัสดีจ้า</title>
<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body style="background-image: url(i.gif);">
  <div class="container mt-6">
    <button type="button" class="btn btn-outline-success"><li class="nav-item">
      <a class="nav-link active" href="C:\xampp\htdocs\testd5\ad\indox.html"><i class='bx bxs-home' ></i><span>หน้าหลัก</span></a>
    </li></button>
    <button type="button" class="btn btn-outline-info">Info</button>     
  </div>
    </div>
  <p>  
    <h1 style="color:#2A629A;">Resume</h1>
    <img src="gg Gz.jpg" alt="Trulli" width="150" height="200">
  <h2 style="color:#2A629A;">ชื่อ: นพนัฐ มาลา</h2>
  <h2 style="color:#2A629A;">ชื่อเล่น: นัฐ  กรุ๊ปเลือด:B</h2>
  <h2 style="color:#2A629A;">ว/ด/ป เกิด: 04/01/2004</h2>
  <h2 style="color:#2A629A;">ที่อยู่ 172/1 หมู่ 11 บ้านโนนทอง ตำบลบ้านกอก อำเภอจัตุรัส จังหวัด ชัยภูมิ </h2>
  <h2 style="color:#2A629A;">เกียวกับฉัน: ง่วงตลอดเวลา</h2>
  <h1 style="color:#2A629A;">ช่องทางติดต่อ</h1>
  <h2 style="color:#2A629A;">Line: nut31178     เบอร์:0638397659</h2>
  <h2 style="color:#2A629A;">facebook:Noppanut Mala  e-mail:noppanutkll@gmail.com</h2>
  <h1 style="color:#2A629A;">ข้อมูลส่วนตัว</h1>
  <h2 style="color:#2A629A;">ชื่อบิดา: นาย รักษ์ มาลา อายุ:45</h2>
  <h2 style="color:#2A629A;">อาชีพ: ชาวนา  เบอร์:083-604-3731 </h2>
  <h2 style="color:#2A629A;">ชื่อบิดา: นาง ขจิต มาลา อายุ:43</h2>
  <h2 style="color:#2A629A;">อาชีพ: แม่ครัว  เบอร์:061-896-2829 </h2>
  <h1 style="color:#2A629A;">ประวัติการศึกษา</h1>
  <h2 style="color:#2A629A;">โรงเรียนศรีเทพบาล</h2>
  <h2 style="color:#2A629A;">โรงเรียนจัตุรัสวิยาคาร</h2>
  <h2 style="color:#2A629A;">โรงเรียนจัตุรัสวิยาคาร</h2>
  <h2 style="color:#2A629A;">โรงเรียนกองทัพบกอุปถัมภ์ ช่างกล ขส.ทบ</h2>
  <h1 style="color:#2A629A;">คติประจำใจ</h1>
  <h2 style="color:#2A629A;">gg Gz</h2>
  <h1 style="color:#2A629A;">งานอดิเรก</h1>
  <h2 style="color:#2A629A;">เล่นหมากรุก  บาร์เทนเดอร์</h2>
  <h1 style="color:#2A629A;">นักศึกษาเลือกเรียนสาขานี้เพราะอะไร ? เรียนจบอยากทำอาชีพอะไร</h1>
  <h2 style="color:#2A629A;">เลือกสาขา it เพราะชอบ จบไปอยากทำอาชีพโปรเเกรมเมอร์</h2>
  </p>
</body>
</html>