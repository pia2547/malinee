<?php /* *** No Copyright for Education (Free to Use and Edit) *** * /
PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018 */ ?>
<html>
<head>
  <meta charset="UTF-8">
  <title>ผลการค้นหา</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 20px;
      background: url('gojo-satoru-infinite-power.3840x2160.mp4') no-repeat center center fixed;
    background-size: cover;
    }
    .video-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
      background-color: #fff;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    table, th, td {
      border: 1px solid #ddd;
    }
    th, td {
      padding: 8px;
      text-align: center;
    }
    th {
      background-color: #f2f2f2;
      color: #333;
    }
    tr:hover {
      background-color: #f1f1f1;
    }
    a {
      color: #007bff;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
    .container {
      max-width: 1200px;
      margin: auto;
      padding: 20px;
    }
    .heading {
      text-align: center;
      margin-bottom: 20px;
    }
    .keyword-input {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
    }
    .keyword-input input[type="text"] {
      padding: 5px;
      width: 300px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .keyword-input input[type="submit"] {
      padding: 5px 10px;
      margin-left: 10px;
      border: none;
      border-radius: 4px;
      background-color: #007bff;
      color: white;
      cursor: pointer;
    }
    .keyword-input input[type="submit"]:hover {
      background-color: #0056b3;
    }
  </style>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<video autoplay muted loop class="video-bg">
        <source src="albedo-overlord-moewalls-com.mp4" type="video/mp4">
    </video>
  <div class="container">
    <h2 class="heading">ผลการค้นหา</h2>
    <div class="keyword-input">
      <form method="GET" action="">
        <input type="text" name="keyword" placeholder="แก้ไขหรือค้นหาเพิ่มเติม..." />
        <input type="submit" value="Search" />
      </form>
    </div>

    <?php
    $keyword  = isset($_REQUEST['keyword']) ? $_REQUEST['keyword'] : '';
    require('connect.php');

    $sql = "
      SELECT * 
      FROM tb_d5_67
      WHERE f_name LIKE '%" . $keyword . "%';
      ";

    $objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");
    ?>

    <table>
      <tr>
        <th>No</th>
        <th>รหัสนักศึกษา</th>
        <th>คำนำหน้า</th>
        <th>ชื่อ</th>
        <th>สกุล</th>
        <th>ชื่อเล่น</th>
        <th>เพศ</th>
        <th>เบอร์</th>
        <th>อีเมล</th>
        <th>แผกนวิชา</th>
        <th>ดูข้อมูล</th>
        <th>Delete</th>
        <th>Update</th>
      </tr>
      <?php
      $i = 1;
      while ($objResult = mysqli_fetch_array($objQuery)) {
      ?>
        <tr>
          <td><?php echo $i; ?></td>
          <td><?php echo $objResult["std_id"]; ?></td>
          <td><?php echo $objResult["n_title"]; ?></td>
          <td><?php echo $objResult["f_name"]; ?></td>
          <td><?php echo $objResult["l_name"]; ?></td>
          <td><?php echo $objResult["n_name"]; ?></td>
          <td><?php echo $objResult["sex"]; ?></td>
          <td><?php echo $objResult["number"]; ?></td>
          <td><?php echo $objResult["e_mail"]; ?></td>
          <td><?php echo $objResult["DepartmentID"]; ?></td>
          <td align="center"><a href="<?php echo $objResult["profile_link"]; ?>"><button type="button" class="btn btn-outline-danger">Profile</button></a></td>
          <td><a href="daletedata.php?std_id=<?php echo $objResult["std_id"]; ?>"><button type="button" class="btn btn-outline-danger">Delete</button></a></td>
          <td><a href="update2.php?std_id=<?php echo $objResult["std_id"]; ?>"<button type="button" class="btn btn-outline-danger">update</button></a></td>
        </tr>
      <?php
        $i++;
      }
      ?>
    </table>
    <?php
    mysqli_close($conn); // ปิดฐานข้อมูล
    echo "<br><br>";
    ?>
  </div>
</body>
</html>
