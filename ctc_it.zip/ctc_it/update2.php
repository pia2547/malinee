<?php /* * No Copyright for Education (Free to Use and Edit) * * /
PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018 */ ?>
<html>

<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <?php
    $update_ID    = $_REQUEST['std_id'];
    $std_id   = $update_ID;
    ?>
    <form action="updatedata.php?std_id=<?php echo $std_id; ?>" method="post" name="std_id">
    <div class="container mt-3">
<table class="table table-bordered">
<thead class="table-danger">
            <tr>
            <h3>แก้ไขข้อมูล</h3>
                <td>รหัสนักศึกษา : </td>
                <td><input type="text" name="std_id" value="<?php echo $std_id; ?>" disabled></td>
            </tr>
            <tr>
                <td>แผนก : </td>
                <?php
                // DepartmentID Query from Table
                require('connect.php');
                $sql = '
    SELECT DepartmentID 
    FROM department;
    ';
                $objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");
                ?>
                <td><select name="DepartmentID">
                        <?php
                        while ($objResult = mysqli_fetch_array($objQuery)) {
                        ?>
                            <option value=<?php echo $objResult["DepartmentID"]; ?>><?php echo $objResult["DepartmentID"]; ?></option>
                        <?php
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>คำนำหน้า : </td>
                <td><input type="text" name="n_title"></td>
            </tr>
            <tr>
                <td>ชื่อ : </td>
                <td><input type="text" name="f_name"></td>
            </tr>
           
           
            <tr>
                <td>นามสกุล : </td>
                <td><input type="text" name="l_name"></td>
            </tr>
            <td>ชื่อเล่น : </td>
                <td><input type="text" name="n_name"></td>
            </tr>
            <tr>
                <td>เพศ : </td>
                <td><input type="text" name="sex"></td>
            </tr>
            <tr>
                <td>เบอร์ : </td>
                <td><input type="text" name="number"></td>
            </tr>
            <tr>
                <td>อีเมล : </td>
                <td><input type="text" name="e_mail"></td>
            </tr>
        </table>
        </thead>

        <br>
        <input type="submit" value="Update Data">
    </form>
    <?php
    mysqli_close($conn); // ปิดฐานข้อมูล
    echo "<br><br>";
    ?>
</body>

</html>