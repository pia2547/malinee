<?php /* * No Copyright for Education (Free to Use and Edit) * * /
PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018 */ ?>
<?php
require('connect.php');

$update_ID    = $_REQUEST['std_id'];
$std_id   = $update_ID;
$n_title	  = $_REQUEST['n_title'];
$f_name		  = $_REQUEST['f_name'];
$l_name		  = $_REQUEST['l_name'];
$n_name		  = $_REQUEST['n_name'];
$sex		  = $_REQUEST['sex'];
$number	  = $_REQUEST['number'];
$e_mail	  = $_REQUEST['e_mail'];
$DepartmentID = $_REQUEST['DepartmentID'];

$sql = "
	UPDATE tb_d5_67
	SET 
	n_title = '" . $n_title . "',
	f_name = '" . $f_name . "', 
	l_name = '" . $l_name . "',  
	n_name = '" . $n_name . "',  
	sex = '" . $sex . "', 
	number = '" . $number . "', 
	e_mail = '" . $e_mail . "', 
	DepartmentID = '" . $DepartmentID . "' 
	WHERE std_id = " . $std_id . " ; ";

$objQuery = mysqli_query($conn, $sql);

if ($objQuery) {
	echo "แก้ไข้ข้อมูลของ " . $update_ID . " เสร็จเรียบร้าย.";
} else {
	echo "แก้ไขข้อมูลไม่สำเร็จ";
}
mysqli_close($conn); // ปิดฐานข้อมูล
echo "<br><br>";
?>